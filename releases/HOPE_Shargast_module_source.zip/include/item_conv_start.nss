
void main()
{
    ActionStartConversation(GetLastUsedBy());
}
